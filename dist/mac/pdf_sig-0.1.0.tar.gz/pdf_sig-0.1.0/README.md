# PDF Sig, Sign PDF for Free

This repo contains a small GUI for loading an existing PDF, dropping an image (e.g., a signature or photo), optionally filling form fields, and saving the result.

## Requirements
- Python 3.10+ (the GUI depends on Tk; install the system Tk/XQuartz libs if they are missing)
- macOS or Windows with a display; headless runs will skip the GUI smoke test

## Setup (dev)
```bash
python -m venv .venv
source .venv/bin/activate       # PowerShell: .venv\Scripts\activate
python -m pip install -r requirements-dev.txt
python -m pip install -e .
```

## Usage (GUI)
After installing the dependencies and activating the virtual environment, launch the Tkinter app:
```bash
sign-pdf-for-free-gui
```
Use the top toolbar buttons (**Open PDF**, **Insert Image**, **Save PDF**) to drive the entire flow. When no document is loaded the canvas shows an "open pdf" hint; once opened, the preview automatically fits the window and navigation arrows let you move between pages. After choosing an image, click on the preview to drop it; drag the illuminated side handles to resize the placement, then press **Save PDF** to bake it into the document.

## Tests & quality
- Run unit tests: `python -m pytest -q`
- With coverage: `python -m pytest --cov=src --cov-report=term-missing`
- Enable the GUI smoke test (requires a display/Tk): `ENABLE_GUI_TESTS=1 python -m pytest -q tests/free_pdf/test_gui_smoke.py`
- Lint/format: `ruff check src tests` and `black src tests`

## Building an executable
After installing the deps above (PyInstaller is not bundled in requirements):
```bash
python -m pip install pyinstaller
pyinstaller -y sign-pdf-for-free-gui-onedir.spec
```
The resulting bundle appears in `dist/sign-pdf-for-free-gui.app` (macOS) with supporting files inside `dist/sign-pdf-for-free-gui/`. Remember to copy any template PDFs or assets the executable expects next to it or bake relative paths into your workflow.

### macOS notes
- Build on a Mac to produce a native Mach-O binary. Running PyInstaller on Windows cannot emit a macOS binary.
- After the build finishes, the binaries live in `dist/`; double-clicking the GUI app may show a Gatekeeper warning on unsigned builds. Either right-click → Open once, or codesign with a Developer ID certificate: `codesign --deep --force --sign "Developer ID Application: Your Name" dist/sign-pdf-for-free-gui`.
- The provided `sign-pdf-for-free-gui-onedir.spec` already targets a macOS-friendly onedir bundle; PyInstaller warns against onefile + .app on macOS.
