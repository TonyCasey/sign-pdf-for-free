"GUI helpers for filling PDF forms and embedding images."

__all__: list[str] = []
